
# Annuities Comparison Calculator

This folder contains your Next.js annuity calculator app.
Follow the same Vercel deployment steps as before.
